package com.example.myapplication;

public class AppConstant {

    public static  int IMAGE_WIDTH;
    public static  int IMAGE_HEIGHT;
    public static float  startingPositionX;
    public static float startingPositionY;
    public static int SPEEDX = 10;
    public static int TIME_TO_SLEEP = 900;
    public static int MAX_NUM_OF_BARS = 10;
    public static int NUM_OF_POWERS = 4;

    public static Powers[] AllPowers;
    public static Powers[] currPowers = new Powers[4];


}
